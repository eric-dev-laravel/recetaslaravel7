<?php $__env->startSection('botones'); ?>
    <?php echo $__env->make('ui.navegacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <h2 class="text-center mb-5">Administra tus Recetas</h2>

    <div class="col-md-10 mx-auto bg-white p-3">
        <table class="table">
            <thead class="bg-primary text-light">
                <tr>
                    <th scope="col">Titulo</th>
                    <th scope="col">Categoria</th>
                    <th scope="col">Acciones</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $recetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($receta->titulo); ?></td>
                        <td><?php echo e($receta->categoria->nombre); ?></td>
                        <td>
                            <a href="<?php echo e(route('recetas.show', ['receta' => $receta->id])); ?>" class="btn btn-success mr-1 d-block mb-2">Ver</a>
                            <a href="<?php echo e(route('recetas.edit', ['receta' => $receta->id])); ?>" class="btn btn-dark mr-1 d-block mb-2">Editar</a>
                            <eliminar-receta
                                receta-id=<?php echo e($receta->id); ?>>
                            </eliminar-receta>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="col-12 mt-4 justify-content-center d-flex">
            <?php echo e($recetas->links()); ?>

        </div>

        <h2 class="text-center my-5">Recetas que te gustan</h2>
        <div class="col-md-10 mx-auto bg-white p-3">
            <?php if(count($usuario->meGusta) > 0): ?>
                <ul class="list-group">
                    <?php $__currentLoopData = $usuario->meGusta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <p><?php echo e($receta->titulo); ?></p>

                            <a class="btn btn-outline-success text-uppercase font-weight-bold" href="<?php echo e(route('recetas.show', ['receta' => $receta->id])); ?>">Ver</a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <p class="text-center">Aún no tienes recetas guardadas.
                    <small> Dale me gusta a las recetas y aparecerán aquí!</small>
                </p>
            <?php endif; ?>
        </div>
        
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ericvargasrosas/Desktop/Laravel Projects/Cursos/Udemy/recetaslaravel/resources/views/recetas/index.blade.php ENDPATH**/ ?>