<div class="col-md-4 mt-4">
                            
    <div class="card shadow">

        <img class="card-img-top" src="/storage/<?php echo e($receta->imagen); ?>" alt="Imagen Receta">

        <div class="card-body">
            <h3 class="card-title"><?php echo e(Str::upper($receta->titulo)); ?></h3>

            <div class="meta-receta d-flex justify-content-between">
                <?php
                    $fecha = $receta->created_at; 
                ?>

                <p class="text-primary fecha font-weight-bold">
                    <fecha-receta fecha="<?php echo e($fecha); ?>"></fecha-receta>
                </p>

                <p><?php echo e(count($receta->likes)); ?> Les gustó</p>
            </div>

            <p><?php echo e(Str::words( strip_tags($receta->preparacion), 20)); ?></p>

            <a href="<?php echo e(route('recetas.show', ['receta' => $receta->id])); ?>"
                class="btn btn-primary d-block btn-receta">
                Ver Receta
            </a>
        </div>

    </div>

</div><?php /**PATH /Users/ericvargasrosas/Desktop/Laravel Projects/Cursos/Udemy/recetaslaravel7/resources/views/ui/receta.blade.php ENDPATH**/ ?>