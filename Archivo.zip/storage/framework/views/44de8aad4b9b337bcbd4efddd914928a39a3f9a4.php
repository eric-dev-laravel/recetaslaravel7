<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('hero'); ?>
    <div class="hero-categorias">
        <form action="<?php echo e(route('buscar.show')); ?>" class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-md-4 texto-buscar">
                    <p class="display-4">Encuentra una receta para tu próxima comida</p>

                    <input 
                        type="search"
                        name="buscar"
                        class="form-control"
                        placeholder="Buscar receta"
                    />
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container recetas-nuevas bg-white pt-5 pl-5 pr-5">
        <h2 class="titulo-categoria text-uppercase mb-4">Últimas recetas</h2>

        <div class="owl-carousel owl-theme">
            <?php $__currentLoopData = $nuevas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nueva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="card">
                        <img src="/storage/<?php echo e($nueva->imagen); ?>" class="card-img-top" alt="imagen receta">
    
                        <div class="card-body">
                            <h3><?php echo e(Str::upper( $nueva->titulo )); ?></h3>

                            <p><?php echo e(Str::words( strip_tags($nueva->preparacion), 20)); ?></p>

                            <a href="<?php echo e(route('recetas.show', ['receta' => $nueva->id])); ?>"
                                class="btn btn-primary d-block font-weight-bold text-uppercase">Ver Receta</a>
                        </div>
                    </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="container bg-white pt-3 pl-5 pr-5">
        <h2 class="titulo-categoria text-uppercase mb-4">Recetas mas Votadas</h2>

        <div class="row">
            <?php $__currentLoopData = $votadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('ui.receta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>

    <?php $__currentLoopData = $recetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container bg-white pt-5 pl-5 pr-5">
            <h2 class="titulo-categoria text-uppercase mb-4"><?php echo e(str_replace('-', ' ', $key)); ?></h2>

            <div class="row">
                <?php $__currentLoopData = $grupo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recetas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $recetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('ui.receta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ericvargasrosas/Desktop/Laravel Projects/Cursos/Udemy/recetaslaravel7/resources/views/inicio/index.blade.php ENDPATH**/ ?>