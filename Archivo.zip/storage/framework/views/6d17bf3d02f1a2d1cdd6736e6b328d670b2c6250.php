<?php $__env->startSection('content'); ?>

    <article class="contenido-receta bg-white p-5 shadow">
        <h1 class="text-center mb-4"> <?php echo e($receta->titulo); ?></h1>

        <div class="imagen-receta">
            <img src="/storage/<?php echo e($receta->imagen); ?>" alt="receta" class="w-100">
        </div>

        <div class="receta-meta mt-3">
            <p>
                <span class="font-weight-bold text-primary">Escrito en:</span>
                <a class="text-dark" href="<?php echo e(route('categorias.show', ['categoriaReceta' => $receta->categoria->id])); ?>">
                    <?php echo e($receta->categoria->nombre); ?>

                </a>
            </p>

            <p>
                <span class="font-weight-bold text-primary">Autor:</span>
                <a class="text-dark" href="<?php echo e(route('perfiles.show', ['perfil' => $receta->autor->id])); ?>">
                    <?php echo e($receta->autor->name); ?>

                </a>
            </p>

            <p>
                <span class="font-weight-bold text-primary">Fecha:</span>
                <?php
                    $fecha = $receta->created_at; 
                ?>

                <fecha-receta fecha="<?php echo e($fecha); ?>"></fecha-receta>

            </p>

            <div class="ingredientes">
                <h2 class="my-3 text-primary">Ingredientes</h2>

                <?php echo $receta->ingredientes; ?>

            </div>

            <div class="preparacion">
                <h2 class="my-3 text-primary">Preparación</h2>

                <?php echo $receta->preparacion; ?>

            </div>

            <div class="justify-content-center row text-center">
                <like-button 
                    receta-id="<?php echo e($receta->id); ?>"
                    like="<?php echo e($like); ?>"
                    likes="<?php echo e($likes); ?>"
                ></like-button>
            </div>

        </div>
    </article>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ericvargasrosas/Desktop/Laravel Projects/Cursos/Udemy/recetaslaravel/resources/views/recetas/show.blade.php ENDPATH**/ ?>